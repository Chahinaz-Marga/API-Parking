// MapWithPlaceholder.jsx
import React from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Configuración del icono por defecto (arregla problemas con iconos en Leaflet)
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
  iconUrl: require('leaflet/dist/images/marker-icon.png'),
  shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
});

// Crear el icono rojo personalizado
const redIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
  shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

function MapWithPlaceholder({ parkings, googleResult, searchRadius, onMarkerClick }) {
  // Definir la posición inicial del mapa
  const defaultPosition = [40.4168, -3.7038]; // Madrid

  // Si hay una ubicación de búsqueda, centrar el mapa allí
  const mapCenter = googleResult ? [googleResult.lat, googleResult.lng] : defaultPosition;

  return (
    <MapContainer center={mapCenter} zoom={13} style={{ height: '100%', width: '100%' }}>
      {/* Capa de mapas */}
      <TileLayer
        attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
        url='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
      />

      {/* Marcador rojo en la ubicación buscada */}
      {googleResult && (
        <>
          <Marker position={[googleResult.lat, googleResult.lng]} icon={redIcon}>
            <Popup>
              <strong>{googleResult.name}</strong>
            </Popup>
          </Marker>

          {/* Círculo verde alrededor de la ubicación */}
          <Circle
            center={[googleResult.lat, googleResult.lng]}
            radius={searchRadius * 1000} // Convertir km a metros
            pathOptions={{ color: 'green', fillColor: 'green', fillOpacity: 0.2 }}
          />
        </>
      )}

      {/* Marcadores de aparcamientos */}
      {parkings && parkings.map((parking) => (
        <Marker
          key={parking.id}
          position={[parking.location.latitude, parking.location.longitude]}
          eventHandlers={{ click: () => onMarkerClick(parking) }}
        >
          <Popup>
            <strong>{parking.title}</strong>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}

export default MapWithPlaceholder;
